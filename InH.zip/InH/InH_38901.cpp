﻿#include <iostream>
#include <cmath>
#include <vector>
#include "Generators.h"
#include "LargeScaleParameters.h"
#include "Antenna.h"
#include "Function.h"
#include "UT.h"
#include "CalculateProbabilityLOS.h"
#include "CalculatePathloss.h"
#include "GenerateClusterDelaysAndPowers.h"
#include "GenerateAngleWithSpread.h"
#include "Generate_rGain.h"

using namespace RandomGenerators;



int main() {

    // Пример генерации случайных чисел с нормальным распределением
    double mean = 0.0; // Среднее значение
    double stddev = 1.0; // Стандартное отклонение
    
    for (int i = 0; i < 5; ++i) {
        double randomGauss = generateGauss(mean, stddev);
        std::cout << randomGauss << " ";
    }
    std::cout << std::endl;


    LargeScaleParameters losParams(true, 5.0);  // LOS, частота 5 ГГц
    LargeScaleParameters nlosParams(false, 5.0); // NLOS, частота 5 ГГц

    // Выводим параметры для LOS случая
    std::cout << "LOS Parameters:" << std::endl;
    losParams.showParameters();

    // Выводим параметры для NLOS случая
    std::cout << "NLOS Parameters:" << std::endl;
    nlosParams.showParameters();

    // Пример использования функции расчета вертикальной диаграммы мощности
    double theta = 45.0; // Угол в градусах
    double verticalPower = calculateVerticalPowerPatternLSC(theta);
    std::cout << "Vertical Power Pattern at theta = " << theta << ": " << verticalPower << std::endl;

    // Пример использования функции расчета горизонтальной диаграммы мощности
    double phi = 30.0; // Угол в градусах
    double horizontalPower = calculateHorizontalPowerPatternLSC(phi);
    std::cout << "Horizontal Power Pattern at phi = " << phi << ": " << horizontalPower << std::endl;

    // Пример использования функции расчета 3D диаграммы мощности
    double powerPattern = calculatePowerPatternLSC(theta, phi);
    std::cout << "3D Power Pattern at theta = " << theta << ", phi = " << phi << ": " << powerPattern << std::endl;

    // Пример использования функции FieldPatternGSC
    double alpha = 10.0; // Угол в градусах
    double beta = 20.0; // Угол в градусах
    double gamma = 30.0; // Угол в градусах
    double ksi = 45.0; // Угол в градусах

    Vector2d fieldPattern = FieldPatternGSC(degreesToRadians(theta), degreesToRadians(phi), degreesToRadians(alpha), degreesToRadians(beta), degreesToRadians(gamma), degreesToRadians(ksi));
    std::cout << "Field Pattern GSC: (" << fieldPattern(0) << ", " << fieldPattern(1) << ")" << std::endl;

    // Пример использования функции создания антенного массива
    int Mg = 1; // Количество групп по вертикали
    int Ng = 2; // Количество групп по горизонтали
    int M = 2;  // Количество элементов по вертикали в группе
    int N = 2;  // Количество элементов по горизонтали в группе
    int P = 1;  // Количество панелей
    double lambda = 0.15; // Длина волны
    MatrixXd antennaArray = createAntennaArray(Mg, Ng, M, N, P, lambda);
    std::cout << "Antenna Array:\n" << antennaArray << std::endl;

    // Пример использования функции поворота антенного массива
    double alphaRotation = M_PI / 4; // Поворот на 45 градусов
    double betaRotation = M_PI / 6; // Поворот на 30 градусов
    double gammaRotation = M_PI / 3; // Поворот на 60 градусов
    MatrixXd rotatedArray = rotateAntennaArray(antennaArray, alphaRotation, betaRotation, gammaRotation);
    std::cout << "Rotated Antenna Array:\n" << rotatedArray << std::endl;


    UT transmitter(1, 0.0, 0.0, 0.0);
    UT receiver(2, 1.0, 1.0, 1.0);

    double losPhiAOD, losThetaZOD, losPhiAOA, losThetaZOA;
    calculateLOSAngles(transmitter, receiver, losPhiAOD, losThetaZOD, losPhiAOA, losThetaZOA);

    std::cout << "Angles of Departure (AOD): " << losPhiAOD << ", " << losThetaZOD << std::endl;
    std::cout << "Angles of Arrival (AOA): " << losPhiAOA << ", " << losThetaZOA << std::endl;

    


    double distance = 10.0; // Пример расстояния
    double frequency = 2.4;  // Пример частоты в ГГц

    // Пример использования для открытого сценария
    bool losOpen = CalculateProbabilityLOS::generateLOSorNLOS(distance, 0);
    
    double pathLossOpen = CalculatePathLoss::calculatePathLoss(losOpen, distance, frequency);
    std::cout << "Path Loss (Open Scenario): " << pathLossOpen << " dB" << std::endl;

    // Пример использования для смешанного сценария
    bool losMixed = CalculateProbabilityLOS::generateLOSorNLOS(distance, 1);
    double pathLossMixed = CalculatePathLoss::calculatePathLoss(losMixed, distance, frequency);
    std::cout << "Path Loss (Mixed Scenario): " << pathLossMixed << " dB" << std::endl;

    
    // Определяем размеры комнаты
    double roomLength = 100.0; // Длина комнаты
    double roomWidth = 50.0;   // Ширина комнаты

    // Создаем матрицу антенн (например, 5 антенн с x, y, z координатами)
    Eigen::MatrixXd antennaArray1(5, 3);
    antennaArray1 << 0, 0, 0,
        10, 10, 0,
        20, 20, 0,
        30, 30, 0,
        40, 40, 0;

    try {
        // Генерируем 6 пар пользователей
        auto userPairs = generateUserPairs(roomLength, roomWidth, antennaArray, lambda);

        // Выводим сгенерированные пары пользователей
        for (const auto& pair : userPairs) {
            std::cout << "User  1: ID=" << pair.first.id << ", x=" << pair.first.x << ", y=" << pair.first.y << ", z=" << pair.first.z << "\n";
            std::cout << "Antenna Matrix for User 1:\n" << pair.first.antennaMatrix << "\n\n"; // Вывод матрицы антенн для первого пользователя

            std::cout << "User  2: ID=" << pair.second.id << ", x=" << pair.second.x << ", y=" << pair.second.y << ", z=" << pair.second.z << "\n";
            std::cout << "Antenna Matrix for User 2:\n" << pair.second.antennaMatrix << "\n\n"; // Вывод матрицы антенн для второго пользователя
        }
    }
    catch (const std::exception& e) {
        std::cerr << "Erorr: " << e.what() << std::endl;
    }

    try {
        // Пример входных параметров
        bool los = true; // Выбор сценария LOS
        double delaySpread = -7.0; // Пример значения для delaySpread (в логарифмическом виде)
        double riceanK = 7.0; // Пример значения для riceanK

        // Генерация задержек
        std::vector<double> delays = ClusterDelaysAndPowers::generateClusterDelays(los, delaySpread, riceanK);

        // Вывод результатов
        std::cout << "Сгенерированные задержки: ";
        for (const auto& delay : delays) {
            std::cout << delay << " ";
        }
        std::cout << std::endl;

        std::vector<double> powers = ClusterDelaysAndPowers::generateClusterPowers(true, delays, delaySpread, riceanK).second;

        // Проверка результатов
        std::cout << "Cluster Delays after filtering: ";
        for (const auto& delay : delays) {
            std::cout << delay << " ";
        }
        std::cout << std::endl;

        std::cout << "Cluster Powers after filtering: ";
        for (const auto& power : powers) {
            std::cout << power << " ";
        }
        std::cout << std::endl;

        // Инициализация матриц для AOD, AOA, ZOD и ZOA
        Eigen::MatrixXd AOD(powers.size() , 20); // +1 для LOS
        Eigen::MatrixXd AOA(powers.size() , 20); // +1 для LOS
        Eigen::MatrixXd ZOD(powers.size() , 20); // +1 для LOS
        Eigen::MatrixXd ZOA(powers.size() , 20); // +1 для LOS

        // Генерация углов выхода (AOD)
        auto resultAOD = AngleWithSpread::generateAOAorAOD_n_m(true, powers, 5.0, 1.0, 30.0, 0);
        std::cout << "Generated AOD:\n" << resultAOD << "\n\n";

        // Генерация углов прихода (AOA)
        auto resultAOA = AngleWithSpread::generateAOAorAOD_n_m(false, powers, 5.0, 1.0, 30.0, 1);
        std::cout << "Generated AOA:\n" << resultAOA << "\n\n";

        // Генерация углов случайного распределения (ZOD)
        auto resultZOD = AngleWithSpread::generateZOAorZOD_n_m(false, powers, 5.0, 1.0, 90.0, 3);
        std::cout << "Generated ZOD:\n" << resultZOD << "\n\n";

        // Генерация углов случайного распределения (ZOA)
        auto resultZOA = AngleWithSpread::generateZOAorZOD_n_m(true, powers, 5.0, 1.0, 90.0, 2);
        std::cout << "Generated ZOA:\n" << resultZOA << "\n\n";

        //// Расчет углового разброса и средних углов
        //auto angularSpread = AngleWithSpread::calculateAngularSpreadandMeanAngles(true,powers, resultAOD, resultAOA, resultZOD, resultZOA);

        //std::cout << "Angular Spread and Mean Angles:\n";
        //std::cout << "AOD Angular Spread: " << angularSpread[0] << ", Mean Angle: " << angularSpread[4] * 180 / M_PI << " degrees\n";
        //std::cout << "AOA Angular Spread: " << angularSpread[1] << ", Mean Angle: " << angularSpread[5] * 180 / M_PI << " degrees\n";
        //std::cout << "ZOD Angular Spread: " << angularSpread[2] << ", Mean Angle: " << angularSpread[6] * 180 / M_PI << " degrees\n";
        //std::cout << "ZOA Angular Spread: " << angularSpread[3] << ", Mean Angle: " << angularSpread[7] * 180 / M_PI << " degrees\n";

        // Случайное распределение лучей
        AngleWithSpread::randomCouplingRays(AOD, AOA, ZOD, ZOA, true);
        std::cout << "Randomly Coupled Rays (AOD, AOA, ZOD, ZOA):\n";
        std::cout << "AOD:\n" << AOD << "\n";
        std::cout << "AOA:\n" << AOA << "\n";
        std::cout << "ZOD:\n" << ZOD << "\n";
        std::cout << "ZOA:\n" << ZOA << "\n";



        std::vector<double> clusterPowers = { 1.0, 2.0, 3.0 }; // Пример значений мощности кластеров

        // Генерация матрицы XPR
        Eigen::MatrixXd XPR = rGain::generateXPR(los, clusterPowers);
        std::cout << "Generated XPR matrix:\n" << XPR << "\n\n";

        // Генерация начальных случайных фаз
        Eigen::MatrixXd initialRandomPhases = rGain::generateInitialRandomPhases(clusterPowers);
        std::cout << "Generated Initial Random Phases matrix:\n" << initialRandomPhases << "\n\n";

        // Тестирование функции generateXPRAndInitialRandomPhases
        int n = 0; // Индекс для теста
        int m = 0; // Индекс для теста

        // Предполагаем, что XRP имеет ту же размерность, что и XPR
        Eigen::MatrixXd XRP = XPR; // Используем XPR как XRP для теста
        Eigen::Matrix2cd XPR_and_InitialRandomPhases = rGain::generateXPRAndInitialRandomPhases(initialRandomPhases, XRP, n, m);

        std::cout << "Generated XPR_and_InitialRandomPhases matrix for n=" << n << ", m=" << m << ":\n" << XPR_and_InitialRandomPhases << "\n";


        std::cout << "All tests passed!" << std::endl;

    }
    catch (const std::invalid_argument& e) {
        std::cerr << "Ошибка: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Произошла ошибка: " << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "Произошла неизвестная ошибка." << std::endl;
    }

    return 0;
}
