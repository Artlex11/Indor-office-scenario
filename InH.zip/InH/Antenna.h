#ifndef ANTENNA_H
#define ANTENNA_H

#include <Eigen/Dense>
#include <iostream>

using namespace Eigen;

const double Phi3dB = 65.0; 
const double Theta3dB = 65.0;
const double SLA_v = 30.0;
const double A_max = 30.0; 
const double MaximumDirectionalGain = 5.0; 


double calculateVerticalPowerPatternLSC(double theta);
double calculateHorizontalPowerPatternLSC(double phi);
double calculatePowerPatternLSC(double theta, double phi);
Vector2d FieldPatternGSC(double theta, double phi, double alpha, double beta, double gamma, double ksi);

MatrixXd createAntennaArray(int Mg, int Ng, int M, int N, int P, double lambda, double dg_H = 0.0, double dg_V = 0.0);

MatrixXd rotateAntennaArray(const MatrixXd& locationMatrixAntennaElements, double alpha, double beta, double gamma);

#endif 
