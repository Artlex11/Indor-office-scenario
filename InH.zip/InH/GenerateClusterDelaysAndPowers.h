#ifndef GENERATECLUSTERDELAYS_H
#define GENERATECLUSTERDELAYS_H

#include <algorithm>
#include <cmath>
#include <vector>

#include "Generators.h"


namespace ClusterDelaysAndPowers {

	const double los_r_tau = 3.6;
	const double nlos_r_tau = 3.0;

	std::vector<double> generateClusterDelays(bool los, double delaySpread, double riceanK);

	std::pair<std::vector<double>, std::vector<double>>  generateClusterPowers(bool los, std::vector<double>& clusterDelays, double delaySpread, double riceanK);

}

#endif 
