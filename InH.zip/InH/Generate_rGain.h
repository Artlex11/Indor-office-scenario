#ifndef GENERATE_RGAIN_H
#define GENERATE_RGAIN_H

#include <Eigen/Dense>
#include <vector>
#include <cmath> 

#include "Generators.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif



namespace rGain {

    Eigen::MatrixXd generateXPR(bool los, const std::vector<double>& clusterPowers); //Step9

    Eigen::MatrixXd generateInitialRandomPhases(std::vector<double>& clusterPowers); //Step10
    
    Eigen::Matrix2cd generateXPRAndInitialRandomPhases(const Eigen::MatrixXd& initialPhases, const Eigen::MatrixXd& XRP, int n, int m); //

} 

#endif 
