#ifndef CALCULATE_PATHLOSS_H
#define CALCULATE_PATHLOSS_H

#include <iostream>
#include <cmath>

namespace CalculatePathLoss { 
    double calculatePathLoss(bool los, double distance, double frequency);
}

#endif // CALCULATE_PATHLOSS_H
