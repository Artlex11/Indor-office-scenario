#ifndef CALCULATE_PROBABILITY_LOS_H
#define CALCULATE_PROBABILITY_LOS_H

#include <iostream>
#include <cmath>
#include "Generators.h"


class CalculateProbabilityLOS {
public:
    static double calculateP_LOS_Open(double distance);
    static double calculateP_LOS_Mixed(double distance);
    /*static double calculateP_LOS_Urban(double distance);
    static double calculateP_LOS_Suburban(double distance);*/
    static bool generateLOSorNLOS(double distance, int scenario);
    static double calculatePathLoss(bool los, double distance, double frequency);
};

#endif #pragma once
