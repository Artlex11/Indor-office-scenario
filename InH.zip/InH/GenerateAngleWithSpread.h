#ifndef GENERATE_ANGLE_WITH_SPREAD_H
#define GENERATE_ANGLE_WITH_SPREAD_H

#include <Eigen/Dense>
#include <vector>
#include <complex>
#include <random>
#include <algorithm>
#include <cmath>

#include "Generators.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif


namespace AngleWithSpread {

    const std::vector<double> los_C = { 8.0, 5.0, 9.0, 0.375 * std::pow(10, -1.43 * std::log(1 + 30) + 2.228) };
    const std::vector<double> nlos_C = { 11.0, 5.0, 9.0, 0.375 * std::pow(10, 1.08) };
    const std::vector<double> am = { 0.0447, -0.0447, 0.1413, -0.1413, 0.2492, -0.2492,
                                      0.3715, -0.3715, 0.5129, -0.5129, 0.6797, -0.6797,
                                      0.8844, -0.8844, 1.1481, -1.1481, 1.5195, -1.5195,
                                      2.1551, -2.1551 };

    Eigen::MatrixXd generateAOAorAOD_n_m(bool los, const std::vector<double>& clusterPowers,
        double ASAorASD, double riceanK, double AOAorAOD, int AOA_0_or_AOD_1);

    Eigen::MatrixXd generateZOAorZOD_n_m(bool los, const std::vector<double>& clusterPowers,
        double ZSAorZSD, double riceanK, double ZOAorZOD, int ZOA_2_or_ZOD_3);

    std::vector<double> calculateAngularSpreadandMeanAngles(bool los, const std::vector<double>& clusterPowers,
        Eigen::MatrixXd& AOD, Eigen::MatrixXd& AOA,
        Eigen::MatrixXd& ZOD, Eigen::MatrixXd& ZOA);

    void randomCouplingRays(Eigen::MatrixXd& matrix1, Eigen::MatrixXd& matrix2,
        Eigen::MatrixXd& matrix3, Eigen::MatrixXd& matrix4, bool los);

} 
#endif