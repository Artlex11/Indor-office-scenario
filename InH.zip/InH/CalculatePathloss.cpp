#include "CalculatePathLoss.h"

namespace CalculatePathLoss { 
    double calculatePathLoss(bool los, double distance, double frequency) {
        return los
            ? 32.4 + 17.3 * log10(distance) + 20 * log10(frequency)
            : 38.3 * log10(distance) + 17.30 + 24.9 * log10(frequency);
    }
}
