#ifndef LARGE_SCALE_PARAMETERS_H
#define LARGE_SCALE_PARAMETERS_H

#include <Eigen/Dense>
#include <cmath>
#include <iostream>
#include <vector>


class LargeScaleParameters {
public:
    LargeScaleParameters(bool losvalue, double fcvalue);

    void showParameters() const;

    
    bool isLos() const { return los; }
    
private:
    double shadowFading;
    double riceanK;
    double delaySpread;
    double azimuthSpreadDeparture;
    double azimuthSpreadArrival;
    double zenithSpreadDeparture;
    double zenithSpreadArrival;
    bool los;
    double fc;

    void initializeLosParameters();
    void initializeNlosParameters();
};

#endif