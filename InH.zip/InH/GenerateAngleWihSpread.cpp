#include "GenerateAngleWithSpread.h"

namespace AngleWithSpread {

    // Function to generate AOA or AOD based on given parameters
    Eigen::MatrixXd generateAOAorAOD_n_m(bool los, const std::vector<double>& clusterPowers,
        double ASAorASD, double riceanK, double AOAorAOD, int AOA_0_or_AOD_1) {
        AOAorAOD = AOAorAOD * 180 / M_PI; // Convert to degrees
        ASAorASD = std::pow(10, ASAorASD); // Convert to linear scale

        

        double maxPower = *std::max_element(clusterPowers.begin(), clusterPowers.end());
        double C_phi = 1.273 * ((0.0001 * riceanK * riceanK * riceanK) - (0.002 * riceanK * riceanK) - (0.028 * riceanK) + 1.1035);

        Eigen::MatrixXd AOAorAOD_n_m(clusterPowers.size() + (los ? 1 : 0), 20);
        Eigen::VectorXd AOAorAOD_n(clusterPowers.size());

        for (size_t n = 0; n < clusterPowers.size(); ++n) {
            double Xn = RandomGenerators::generateUniformFromVector(std::vector<int>{ -1, 1 });
            double Yn = RandomGenerators::generateGauss(0.0, (ASAorASD / 7.0));

            // Calculate AOA or AOD
            AOAorAOD_n(n) = 2.0 * (ASAorASD / 1.4) * std::sqrt(-std::log(clusterPowers[n] / maxPower)) / C_phi;

            if (los && n == 0) {
                AOAorAOD_n_m(n, 0) = AOAorAOD; // Initialize first value
            }

            // Update the value based on previous results
            AOAorAOD_n(n) = AOAorAOD_n(n) * Xn + Yn + AOAorAOD;

            for (int m = 0; m < 20; ++m) {
                AOAorAOD_n_m(n + (los ? 1 : 0), m) = AOAorAOD_n(n) + (los ? los_C[AOA_0_or_AOD_1] : nlos_C[AOA_0_or_AOD_1]) * am[m];
                // Normalize angles to [-180, 180]
                while (AOAorAOD_n_m(n + (los ? 1 : 0), m) < -180) AOAorAOD_n_m(n + (los ? 1 : 0), m) += 360;
                while (AOAorAOD_n_m(n + (los ? 1 : 0), m) > 180) AOAorAOD_n_m(n + (los ? 1 : 0), m) -= 360;
            }
        }
        return AOAorAOD_n_m;
    }

    // Function to generate ZOA or ZOD based on given parameters
    Eigen::MatrixXd generateZOAorZOD_n_m(bool los, const std::vector<double>& clusterPowers,
        double ZSAorZSD, double riceanK, double ZOAorZOD, int ZOA_2_or_ZOD_3) {
        ZOAorZOD = ZOAorZOD * 180 / M_PI; // Convert to degrees
        ZSAorZSD = std::pow(10, ZSAorZSD); // Convert to linear scale
      
        double maxPower = *std::max_element(clusterPowers.begin(), clusterPowers.end());
        double C_theta = 1.184 * ((0.0002 * riceanK * riceanK * riceanK) - (0.0077 * riceanK * riceanK) + (0.0339 * riceanK) + 1.3086);

        Eigen::MatrixXd ZOAorZOD_n_m(clusterPowers.size() + (los ? 1 : 0), 20);
        Eigen::VectorXd ZOAorZOD_n(clusterPowers.size());

        for (size_t n = 0; n < clusterPowers.size(); ++n) {
            double Xn = RandomGenerators::generateUniformFromVector(std::vector<int>{ -1, 1 });
            double Yn = RandomGenerators::generateGauss(0.0, (ZSAorZSD / 7.0));

            // Calculate ZOA or ZOD
            ZOAorZOD_n(n) = -1 * ZSAorZSD * std::log(clusterPowers[n] / maxPower) / C_theta;

            if (los && n == 0) {
                ZOAorZOD_n_m(n, 0) = ZOAorZOD; // Initialize first value
            }

            // Update the value based on previous results
            ZOAorZOD_n(n) = ZOAorZOD_n(n) * Xn + Yn + ZOAorZOD;

            for (int m = 0; m < 20; ++m) {
                ZOAorZOD_n_m(n + (los ? 1 : 0), m) = ZOAorZOD_n(n) + (los ? los_C[ZOA_2_or_ZOD_3] : nlos_C[ZOA_2_or_ZOD_3]) * am[m];
                // Normalize angles to [0, 360]
                if (ZOAorZOD_n_m(n + (los ? 1 : 0), m) >= 180) {
                    ZOAorZOD_n_m(n + (los ? 1 : 0), m) = 360 - ZOAorZOD_n_m(n + (los ? 1 : 0), m);
                }
            }
        }
        return ZOAorZOD_n_m;
    }

    // Function to calculate angular spread and mean angles
    std::vector<double> calculateAngularSpreadandMeanAngles(bool los, const std::vector<double>& clusterPowers,
        Eigen::MatrixXd& AOD, Eigen::MatrixXd& AOA,
        Eigen::MatrixXd& ZOD, Eigen::MatrixXd& ZOA) {
        std::vector<double> ASandMeanAnglesforAOD_AOA_ZOD_ZOA;
        AOD *= M_PI / 180;
        AOA *= M_PI / 180;
        ZOD *= M_PI / 180;
        ZOA *= M_PI / 180;

        std::complex<double> weighted_sumAOA(0.0, 0.0);
        std::complex<double> weighted_sumAOD(0.0, 0.0);
        std::complex<double> weighted_sumZOA(0.0, 0.0);
        std::complex<double> weighted_sumZOD(0.0, 0.0);
        double weighted_sumPowers = 0.0;

        // Calculate weighted sums
        for (size_t n = 0; n < clusterPowers.size(); ++n) {
            for (int m = 0; m < 20; ++m) {
                double weight = clusterPowers[n] / 20;
                weighted_sumAOD += weight * std::complex<double>(std::cos(AOD(n + (los ? 1 : 0), m)), std::sin(AOD(n + (los ? 1 : 0), m)));
                weighted_sumAOA += weight * std::complex<double>(std::cos(AOA(n + (los ? 1 : 0), m)), std::sin(AOA(n + (los ? 1 : 0), m)));
                weighted_sumZOD += weight * std::complex<double>(std::cos(ZOD(n + (los ? 1 : 0), m)), std::sin(ZOD(n + (los ? 1 : 0), m)));
                weighted_sumZOA += weight * std::complex<double>(std::cos(ZOA(n + (los ? 1 : 0), m)), std::sin(ZOA(n + (los ? 1 : 0), m)));
                weighted_sumPowers += weight;
            }
        }

        // Calculate angular spreads
        ASandMeanAnglesforAOD_AOA_ZOD_ZOA.push_back(std::sqrt(-2.0 * std::log(std::abs(weighted_sumAOD / weighted_sumPowers))));
        ASandMeanAnglesforAOD_AOA_ZOD_ZOA.push_back(std::sqrt(-2.0 * std::log(std::abs(weighted_sumAOA / weighted_sumPowers))));
        ASandMeanAnglesforAOD_AOA_ZOD_ZOA.push_back(std::sqrt(-2.0 * std::log(std::abs(weighted_sumZOD / weighted_sumPowers))));
        ASandMeanAnglesforAOD_AOA_ZOD_ZOA.push_back(std::sqrt(-2.0 * std::log(std::abs(weighted_sumZOA / weighted_sumPowers))));

        // Calculate mean angles
        ASandMeanAnglesforAOD_AOA_ZOD_ZOA.push_back(std::atan2(weighted_sumAOD.imag(), weighted_sumAOD.real()));
        ASandMeanAnglesforAOD_AOA_ZOD_ZOA.push_back(std::atan2(weighted_sumAOA.imag(), weighted_sumAOA.real()));
        ASandMeanAnglesforAOD_AOA_ZOD_ZOA.push_back(std::atan2(weighted_sumZOD.imag(), weighted_sumZOD.real()));
        ASandMeanAnglesforAOD_AOA_ZOD_ZOA.push_back(std::atan2(weighted_sumZOA.imag(), weighted_sumZOA.real()));

        return ASandMeanAnglesforAOD_AOA_ZOD_ZOA;
    }

    // Function to randomize coupling of rays
    void randomCouplingRays(Eigen::MatrixXd& matrix1, Eigen::MatrixXd& matrix2,
        Eigen::MatrixXd& matrix3, Eigen::MatrixXd& matrix4, bool los) {
        std::mt19937 gens[4] = {
            std::mt19937(std::random_device{}()),
            std::mt19937(std::random_device{}()),
            std::mt19937(std::random_device{}()),
            std::mt19937(std::random_device{}())
        };

        Eigen::MatrixXd* matrices[] = { &matrix1, &matrix2, &matrix3, &matrix4 };

        // Indices for sub-clusters
        std::vector<int> category1 = { 0, 1, 2, 3, 4, 5, 6, 7, 18, 19 }; // 1st sub-cluster
        std::vector<int> category2 = { 8, 9, 10, 11, 16, 17 }; // 2nd sub-cluster
        std::vector<int> category3 = { 12, 13, 14, 15 }; // 3rd sub-cluster

        for (size_t i = 0; i < 4; ++i) {
            for (int j = 0; j < matrices[i]->rows(); ++j) {
                std::vector<double> row(20);
                for (int k = 0; k < 20; ++k) {
                    row[k] = (*matrices[i])(j, k);
                }

                // Shuffle based on LOS or NLOS
                if (los) {
                    if (j > 0) {
                        if (j == 1 || j == 2) {
                            // Shuffle elements from each sub-cluster
                            std::shuffle(category1.begin(), category1.end(), gens[i]);
                            std::shuffle(category2.begin(), category2.end(), gens[i]);
                            std::shuffle(category3.begin(), category3.end(), gens[i]);
                        }
                    }
                }
                else {
                    if (j < 2) {
                        std::shuffle(category1.begin(), category1.end(), gens[i]);
                        std::shuffle(category2.begin(), category2.end(), gens[i]);
                        std::shuffle(category3.begin(), category3.end(), gens[i]);
                    }
                }

                // Shuffle the rest of the row
                if (j >= (los ? 3 : 2)) {
                    std::shuffle(row.begin(), row.end(), gens[i]);
                }

                for (int k = 0; k < 20; ++k) {
                    (*matrices[i])(j, k) = row[k];
                }
            }
        }
    }

} // namespace AngleWithSpread
