#include "LargeScaleParameters.h"
#include "Generators.h"

LargeScaleParameters::LargeScaleParameters(bool losvalue, double fcvalue) : los(losvalue), fc(fcvalue) {
    if (los) {
        initializeLosParameters();
    }
    else {
        initializeNlosParameters();
    }
}

void LargeScaleParameters::initializeLosParameters() {
    double StandardDeviationSF = 3;
    double StandardDeviationK = 4;
    double StandardDeviationDS = 0.18;
    double StandardDeviationASD = 0.18;
    double StandardDeviationASA = (0.12 * log10(1 + fc) + 0.119);
    double StandardDeviationZSA = (-0.04 * log10(1 + fc) + 0.264);
    double StandardDeviationZSD = (fc < 6.0) ? (0.13 * log10(1 + 6) + 0.30) : (0.13 * log10(1 + fc) + 0.30);

    double MeanSF = 0;
    double MeanK = 7;
    double MeanDS = (-0.01 * log10(1 + fc) - 7.692);
    double MeanASD = 1.6;
    double MeanASA = (-0.19 * log10(1 + fc) + 1.781);
    double MeanZSA = (-0.26 * log10(1 + fc) + 1.44);
    double MeanZSD = (fc < 6.0) ? (-1.43 * log10(1 + 6) + 2.228) : (-1.43 * log10(1 + fc) + 2.228);

    Eigen::VectorXd value(7);
    Eigen::VectorXd means(7);
    Eigen::MatrixXd C(7, 7);

    
    means << MeanSF, MeanK, MeanDS, MeanASD, MeanASA, MeanZSD, MeanZSA;

    C << StandardDeviationSF * StandardDeviationSF, 0.5 * StandardDeviationSF * StandardDeviationK, -0.8 * StandardDeviationSF * StandardDeviationDS, -0.4 * StandardDeviationSF * StandardDeviationASD, -0.5 * StandardDeviationSF * StandardDeviationASA, 0.2 * StandardDeviationSF * StandardDeviationZSD, 0.3 * StandardDeviationSF * StandardDeviationZSA,
        0.5 * StandardDeviationK * StandardDeviationSF, StandardDeviationK* StandardDeviationK, -0.5 * StandardDeviationK * StandardDeviationDS, 0.0 * StandardDeviationK * StandardDeviationASD, 0.0 * StandardDeviationK * StandardDeviationASA, 0.0 * StandardDeviationK * StandardDeviationZSD, 0.1 * StandardDeviationK * StandardDeviationZSA,
        -0.8 * StandardDeviationDS * StandardDeviationSF, -0.5 * StandardDeviationDS * StandardDeviationK, StandardDeviationDS* StandardDeviationDS, 0.6 * StandardDeviationDS * StandardDeviationASD, 0.8 * StandardDeviationDS * StandardDeviationASA, 0.1 * StandardDeviationDS * StandardDeviationZSD, 0.2 * StandardDeviationDS * StandardDeviationZSA,
        -0.4 * StandardDeviationASD * StandardDeviationSF, 0.0 * StandardDeviationASD * StandardDeviationK, 0.6 * StandardDeviationASD * StandardDeviationDS, StandardDeviationASD* StandardDeviationASD, 0.4 * StandardDeviationASD * StandardDeviationASA, 0.5 * StandardDeviationASD * StandardDeviationZSD, 0.0 * StandardDeviationASD * StandardDeviationZSA,
        -0.5 * StandardDeviationASA * StandardDeviationSF, 0.0 * StandardDeviationASA * StandardDeviationK, 0.8 * StandardDeviationASA * StandardDeviationDS, 0.4 * StandardDeviationASA * StandardDeviationASD, StandardDeviationASA* StandardDeviationASA, 0.0 * StandardDeviationASA * StandardDeviationZSD, 0.5 * StandardDeviationASA * StandardDeviationZSA,
        0.2 * StandardDeviationZSD * StandardDeviationSF, 0.0 * StandardDeviationZSD * StandardDeviationK, 0.1 * StandardDeviationZSD * StandardDeviationDS, 0.5 * StandardDeviationZSD * StandardDeviationASD, 0.0 * StandardDeviationZSD * StandardDeviationASA, StandardDeviationZSD* StandardDeviationZSD, 0.0 * StandardDeviationZSD * StandardDeviationZSA,
        0.3 * StandardDeviationZSA * StandardDeviationSF, 0.1 * StandardDeviationZSA * StandardDeviationK, 0.2 * StandardDeviationZSA * StandardDeviationDS, 0.0 * StandardDeviationZSA * StandardDeviationASD, 0.5 * StandardDeviationZSA * StandardDeviationASA, 0.0 * StandardDeviationZSA * StandardDeviationZSD, StandardDeviationZSA* StandardDeviationZSA;

    Eigen::MatrixXd L = C.llt().matrixL();

    for (int i = 0; i < 7; ++i) {
        value(i) = RandomGenerators::generateGauss(0.0, 1.0);
    }

    Eigen::VectorXd value_new = L * value + means;

    shadowFading = value_new(0);
    riceanK = value_new(1);
    delaySpread = value_new(2);
    azimuthSpreadDeparture = std::min(value_new(3), log10(104.0));
    azimuthSpreadArrival = std::min(value_new(4), log10(104.0));
    zenithSpreadDeparture = std::min(value_new(5), log10(52.0));
    zenithSpreadArrival = std::min(value_new(6), log10(52.0));
}

void LargeScaleParameters::initializeNlosParameters() {
    double StandardDeviationSF = 8.03;
    double StandardDeviationDS = (0.10 * log10(1 + fc) + 0.055);
    double StandardDeviationASD = 0.25;
    double StandardDeviationASA = (0.12 * log10(1 + fc) + 0.059);
    double StandardDeviationZSA = (-0.09 * log10(1 + fc) + 0.746);
    double StandardDeviationZSD = 0.36;

    double MeanSF = 0;
    double MeanDS = (-0.28 * log10(1 + fc) - 7.173);
    double MeanASD = 1.62;
    double MeanASA = (-0.11 * log10(1 + fc) + 1.863);
    double MeanZSA = (-0.15 * log10(1 + fc) + 1.387);
    double MeanZSD = 1.08;

    Eigen::VectorXd value(6);
    Eigen::VectorXd means(6);
    Eigen::MatrixXd C(6, 6);

    
    means << MeanSF, MeanDS, MeanASD, MeanASA, MeanZSD, MeanZSA;

    C << StandardDeviationSF * StandardDeviationSF, -0.5 * StandardDeviationSF * StandardDeviationDS, 0.0 * StandardDeviationSF * StandardDeviationASD, -0.4 * StandardDeviationSF * StandardDeviationASA, 0.0 * StandardDeviationSF * StandardDeviationZSD, 0.0 * StandardDeviationSF * StandardDeviationZSA,
        -0.5 * StandardDeviationDS * StandardDeviationSF, StandardDeviationDS* StandardDeviationDS, 0.4 * StandardDeviationDS * StandardDeviationASD, 0.0 * StandardDeviationDS * StandardDeviationASA, -0.27 * StandardDeviationDS * StandardDeviationZSD, -0.06 * StandardDeviationDS * StandardDeviationZSA,
        0.0 * StandardDeviationASD * StandardDeviationSF, 0.4 * StandardDeviationASD * StandardDeviationDS, StandardDeviationASD* StandardDeviationASD, 0.0 * StandardDeviationASD * StandardDeviationASA, 0.35 * StandardDeviationASD * StandardDeviationZSD, 0.23 * StandardDeviationASD * StandardDeviationZSA,
        -0.4 * StandardDeviationASA * StandardDeviationSF, 0.0 * StandardDeviationASA * StandardDeviationDS, 0.0 * StandardDeviationASA * StandardDeviationASD, StandardDeviationASA* StandardDeviationASA, -0.08 * StandardDeviationASA * StandardDeviationZSD, 0.43 * StandardDeviationASA * StandardDeviationZSA,
        0.0 * StandardDeviationZSD * StandardDeviationSF, -0.27 * StandardDeviationZSD * StandardDeviationDS, 0.35 * StandardDeviationZSD * StandardDeviationASD, -0.08 * StandardDeviationZSD * StandardDeviationASA, StandardDeviationZSD* StandardDeviationZSD, 0.42 * StandardDeviationZSD * StandardDeviationZSA,
        0.0 * StandardDeviationZSA * StandardDeviationSF, -0.06 * StandardDeviationZSA * StandardDeviationDS, 0.23 * StandardDeviationZSA * StandardDeviationASD, 0.43 * StandardDeviationZSA * StandardDeviationASA, 0.42 * StandardDeviationZSA * StandardDeviationZSD, StandardDeviationZSA* StandardDeviationZSA;

    Eigen::MatrixXd L = C.llt().matrixL();

    for (int i = 0; i < 6; ++i) {
        value(i) = RandomGenerators::generateGauss(0.0, 1.0);
    }

    Eigen::VectorXd value_new = L * value + means;

    shadowFading = value_new(0);
    delaySpread = value_new(1);
    azimuthSpreadDeparture = std::min(value_new(2), log10(104.0));
    azimuthSpreadArrival = std::min(value_new(3), log10(104.0));
    zenithSpreadDeparture = std::min(value_new(4), log10(52.0));
    zenithSpreadArrival = std::min(value_new(5), log10(52.0));
}

void LargeScaleParameters::showParameters() const {
    if (los) {
        std::cout << "SF [dB] : " << shadowFading << ",\nK [dB] : " << riceanK << ",\nDS [log10(DS/1s)] : " << delaySpread << ",\nASD [log10(ASD/ 1* degree] : " << azimuthSpreadDeparture << ",\nASA [log10(ASA/ 1* degree] : " << azimuthSpreadArrival << ",\nZSD [log10(ZSD/ 1* degree] : " << zenithSpreadDeparture << ",\nZSA [log10(ZSA/ 1* degree] : " << zenithSpreadArrival << std::endl << std::endl;
    }
    else {
        std::cout << "SF [dB] : " << shadowFading << ",\nDS [log10(DS/1s)] : " << delaySpread << ",\nASD [log10(ASD/ 1* degree] : " << azimuthSpreadDeparture << ",\nASA [log10(ASA/ 1* degree] : " << azimuthSpreadArrival << ",\nZSD [log10(ZSD/ 1* degree] : " << zenithSpreadDeparture << ",\nZSA [log10(ZSA/ 1* degree] : " << zenithSpreadArrival << std::endl << std::endl;
    }
}
